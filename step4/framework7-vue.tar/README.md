<a href="https://www.patreon.com/vladimirkharlampidi"><img src="https://cdn.framework7.io/i/support-badge.png" height="20"></a>

# Framework7 Vue

Framework7 Vue combines power and simplicity of great Vue.js framework with flexibility and UI of Framework7 mobile framework to build mobile apps in even more easy and quick way.

## Getting Started with Framework7 Vue
  * [Installation Guide](http://framework7.io/vue/installation.html)
  * [Starter App Templates](http://framework7.io/templates/)
  * [App Layout](http://framework7.io/vue/app-layout.html)
  * [Initialize App](http://framework7.io/vue/init-app.html)
  * [Navigation Router](http://framework7.io/vue/navigation-router.html)

## Docs

Documentation available at http://framework7.io/vue/

## Forum

If you have questions about Framework7 or want to help others you are welcome to special forum at http://forum.framework7.io/

## Tutorials

Tutorials available at http://framework7.io/tutorials/

## Showcase

Appstore apps made with Framework7: http://framework7.io/showcase/